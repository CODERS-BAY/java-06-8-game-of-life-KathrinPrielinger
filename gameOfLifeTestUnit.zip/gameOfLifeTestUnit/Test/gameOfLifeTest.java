import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

public class gameOfLifeTest {

    @Test
    public void testNoAliveNeighbours() {


        boolean[][] field = {
                {false, false, false},
                {false, false, false},
                {false, false, false}
        };
        int result = GameOFLife.countNachbarn(field, 1, 1);
        assertEquals(result, 0);
    }

    @Test
    public void testallaliveNeighbours() {
        boolean[][] field = {
                {true, true, true},
                {true, true, true},
                {true, true, true}
        };
        int result = GameOFLife.countNachbarn(field, 1, 1);
        assertEquals(8, result);
    }

    @Test
    public void testsomeNeighbours() {
        boolean[][] field = {
                {true, false, true},
                {true, true, false},
                {false, true, true}
        };
        int result = GameOFLife.countNachbarn(field, 1, 1);
        assertEquals(5, result);
    }


    @Test
    public void testsingleNeighbours() {
        boolean[][] field = {
                {false, false, false},
                {false, false, false},
                {true, false, true}
        };
        int result = GameOFLife.countNachbarn(field, 1, 1);
        assertEquals(2, result);
    }


    @Test
    public void testgetuppperCornerAliveneighbours() {
        boolean[][] field = {
                {false, true, false},
                {false, true, false},
                {false, false, true}
        };
        int result = GameOFLife.countNachbarn(field, 0, 0);
        assertEquals(2, result);
    }


    @Test
    public void testgetlowerCornerAliveneighbours() {
        boolean[][] field = {
                {false, true, false},
                {false, true, false},
                {false, false, true}
        };
        int result = GameOFLife.countNachbarn(field, 0, 0);
        assertEquals(2, result);
    }

    @Test
    public void testDiesofLoneliness() {
        boolean lives = GameOFLife.lives(0, true);
        assertEquals(false, lives);

        lives = GameOFLife.lives(1, true);
        assertEquals(false, lives);
    }

    @Test
    public void testStaysAlive() {
        boolean lives = GameOFLife.lives(2, true);
        assertEquals(true, lives);

        lives = GameOFLife.lives(3, true);
        assertEquals(true, lives);
    }

    @Test
    public void testDiesofOvercrowding() {
        boolean lives = GameOFLife.lives(4, true);
        assertEquals(false, lives);

        lives = GameOFLife.lives(5, true);
        assertEquals(false, lives);
    }

    @Test
    public void testStayDead() {
        boolean lives = GameOFLife.lives(2, false);
        assertEquals(false, lives);
        lives = GameOFLife.lives(4, false);
        assertEquals(false, lives);

    }

    @Test
    public void testReseraction() {
        boolean lives = GameOFLife.lives(3, false);
        assertEquals(true, lives);

    }

    @Test
    public void testnextGen() {
        boolean[][] curentGen = {
                {true, true, false, false, true},
                {true, false, false, false, false},
                {false, false, false, false, false},
                {false, false, false, true, true},
                {false, false, false, true, false},
        };
        boolean[][] expectnextGen = {
                {true, true, false, false, false},
                {true, true, false, false, false},
                {false, false, false, false, false},
                {false, false, false, true, true},
                {false, false, false, true, true},
        };

        boolean[][] nextGen = GameOFLife.nextGen(curentGen);
        for (int i = 0; i < expectnextGen.length; i++) {
            for (int j = 0; j < expectnextGen.length; j++) {
                assertEquals(expectnextGen[i][j], nextGen[i][j]);
            }

        }
    }
}