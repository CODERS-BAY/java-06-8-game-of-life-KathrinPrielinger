public class GameOFLife {

    public static void main(String[] args) {

        boolean[][] initial = {
                {false, false, false, false, false, false, false, false},
                {false, false, true, false, false, false, false, false},
                {false, false, false, true, false, false, false, false},
                {false, true, true, true, false, false, false, false},
                {false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false}
        };
        for (int i = 0; i < 10; i++) {
            boolean[][] nextGene = nextGen(initial);
            initial = nextGene;
            print(initial);
            System.out.println();
        }
    }

    public static void print(boolean[][] generation) {
        for (int i = 0; i < generation.length; i++) {
            for (int j = 0; j < generation.length; j++) {
                System.out.print(generation[i][j] ? "#" : ".");
            }
            System.out.println();
        }
    }

    public static boolean[][] nextGen(boolean[][] curentGen) {
        boolean[][] nextGen = new boolean[curentGen.length][curentGen.length];
        for (int i = 0; i < curentGen.length; i++) {
            for (int j = 0; j < curentGen.length; j++) {
                int nachbarn = countNachbarn(curentGen, i, j);
                nextGen[i][j] = lives(nachbarn, curentGen[i][j]);
            }

        }
        return nextGen;
    }


    public static boolean lives(int lebendeNachbarn, boolean isAlive) {
        if (isAlive) {
            return lebendeNachbarn == 2 || lebendeNachbarn == 3;
        } else {
            return lebendeNachbarn == 3;
        }
    }


    public static int countNachbarn(boolean[][] field, int x, int y) {
        //links oben, oben, rechts oben
        //links,rechts
        //links untnen,unten,rechts unten

        int numberofLivingneighbours = 0;
        //Up
        if (x > 0) {
            if (y > 0) {
                boolean upleftAlive = field[x - 1][y - 1];
                if (upleftAlive) {
                    numberofLivingneighbours++;
                }
            }
        }


        if (y > 0) {
            boolean upAlive = field[x][y - 1];
            if (upAlive) {
                numberofLivingneighbours++;
            }
        }

        if (x < field.length - 1) {
            if (y > 0) {
                boolean uprightAlive = field[x + 1][y - 1];
                if (uprightAlive) {
                    numberofLivingneighbours++;
                }
            }
        }


        //Middle
        if (x > 0) {
            boolean leftAlive = field[x - 1][y];
            if (leftAlive) {
                numberofLivingneighbours++;
            }
        }

        if (x < field.length - 1) {
            boolean rightAlive = field[x + 1][y];
            if (rightAlive) {
                numberofLivingneighbours++;
            }
        }

        //Down
        if (x > 0) {
            if (y < field.length - 1) {
                boolean downleftAlive = field[x - 1][y + 1];
                if (downleftAlive) {
                    numberofLivingneighbours++;
                }
            }
        }
        if (y < field.length - 1) {
            boolean downAlive = field[x][y + 1];
            if (downAlive) {
                numberofLivingneighbours++;
            }
        }

        if (x < field.length - 1) {
            if (y < field.length - 1) {
                boolean downrightAlive = field[x + 1][y + 1];
                if (downrightAlive) {
                    numberofLivingneighbours++;
                }
            }

        }
        return numberofLivingneighbours;

    /*
        int numberOfLivingNeighbours = 0;

        if (zeile > 0 && spalte > 0) {
            boolean upperLeftAlive = field[spalte - 1][zeile - 1];
            if (upperLeftAlive) {
                numberOfLivingNeighbours++;
            }
        }
        if (zeile > 0) {
            boolean upperAlive = field[spalte][zeile - 1];
            if (upperAlive) {
                numberOfLivingNeighbours++;
            }
        }

        if (spalte > 0) {
            boolean upperRightAlive = field[spalte - 1][zeile + 1];
            if (upperRightAlive) {
                numberOfLivingNeighbours++;
            }
        }

        if (spalte > 0) {
            boolean leftAlive = field[spalte - 1][zeile];
            if (leftAlive) {
                numberOfLivingNeighbours++;
            }
        }

        boolean rightAlive = field[spalte + 1][zeile];
        if (rightAlive) {
            numberOfLivingNeighbours++;
        }

        if (zeile > 0) {
            boolean lowerLeftAlive = field[spalte + 1][zeile - 1];
            if (lowerLeftAlive) {
                numberOfLivingNeighbours++;
            }
        }

        boolean lowerAlive = field[spalte+1][zeile];
        if (lowerAlive) {
            numberOfLivingNeighbours++;
        }

        boolean lowerRightAlive = field[spalte + 1][zeile + 1];
        if (lowerRightAlive) {
            numberOfLivingNeighbours++;
        }

        return numberOfLivingNeighbours;
    }

     */
    }
}